module.exports = require('../../netlify/functions/admin-assignments-delete.js');
