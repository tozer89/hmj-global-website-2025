module.exports = require('../../netlify/functions/admin-clients-delete-2.js');
