module.exports = require('../../netlify/functions/supa-health.js');
