module.exports = require('../../netlify/functions/admin-assignments-dropdowns.js');
