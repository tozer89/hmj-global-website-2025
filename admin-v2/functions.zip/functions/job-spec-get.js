module.exports = require('../../netlify/functions/job-spec-get.js');
