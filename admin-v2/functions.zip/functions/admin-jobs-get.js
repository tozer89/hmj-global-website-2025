module.exports = require('../../netlify/functions/admin-jobs-get.js');
