module.exports = require('../../netlify/functions/admin-candidates-lists-2.js');
