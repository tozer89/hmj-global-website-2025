module.exports = require('../../netlify/functions/admin-assignments-get.js');
