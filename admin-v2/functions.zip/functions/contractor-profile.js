module.exports = require('../../netlify/functions/contractor-profile.js');
