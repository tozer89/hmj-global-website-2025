module.exports = require('../../netlify/functions/admin-candidates-list.js');
