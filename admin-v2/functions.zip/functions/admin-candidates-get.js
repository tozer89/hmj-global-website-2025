module.exports = require('../../netlify/functions/admin-candidates-get.js');
