module.exports = require('../../netlify/functions/whoami.js');
