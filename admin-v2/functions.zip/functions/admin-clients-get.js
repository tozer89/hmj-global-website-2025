module.exports = require('../../netlify/functions/admin-clients-get.js');
