module.exports = require('../../netlify/functions/admin-payroll-process.js');
