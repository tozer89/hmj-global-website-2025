module.exports = require('../../netlify/functions/admin-report-gross-margin.js');
