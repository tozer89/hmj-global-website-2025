module.exports = require('../../netlify/functions/public-settings.js');
