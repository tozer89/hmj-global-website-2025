module.exports = require('../../netlify/functions/admin-assignments-save.js');
