module.exports = require('../../netlify/functions/admin-jobs-delete.js');
