module.exports = require('../../netlify/functions/admin-job-share-create.js');
