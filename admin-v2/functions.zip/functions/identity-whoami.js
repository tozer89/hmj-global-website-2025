module.exports = require('../../netlify/functions/identity-whoami.js');
