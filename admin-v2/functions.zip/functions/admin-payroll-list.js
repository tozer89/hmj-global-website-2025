module.exports = require('../../netlify/functions/admin-payroll-list.js');
