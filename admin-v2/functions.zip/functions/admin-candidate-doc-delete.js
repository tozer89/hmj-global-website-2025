module.exports = require('../../netlify/functions/admin-candidate-doc-delete.js');
