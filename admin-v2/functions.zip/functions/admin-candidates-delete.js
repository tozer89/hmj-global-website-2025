module.exports = require('../../netlify/functions/admin-candidates-delete.js');
