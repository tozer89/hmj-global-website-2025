module.exports = require('../../netlify/functions/admin-settings-save.js');
