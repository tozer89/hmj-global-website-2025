module.exports = require('../../netlify/functions/admin-clients-delete.js');
