module.exports = require('../../netlify/functions/admin-candidate-doc-upload.js');
