module.exports = require('../../netlify/functions/admin-timesheets-edit.js');
