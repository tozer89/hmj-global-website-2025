module.exports = require('../../netlify/functions/admin-role-check.js');
