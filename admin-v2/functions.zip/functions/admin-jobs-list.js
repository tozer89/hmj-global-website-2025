module.exports = require('../../netlify/functions/admin-jobs-list.js');
