module.exports = require('../../netlify/functions/admin-contractors-get.js');
