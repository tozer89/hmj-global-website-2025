module.exports = require('../../netlify/functions/admin-candidate-docs-list.js');
