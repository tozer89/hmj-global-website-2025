module.exports = require('../../netlify/functions/admin-contractors-list.js');
