module.exports = require('../../netlify/functions/admin-assignments-list.js');
