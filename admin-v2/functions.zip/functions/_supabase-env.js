module.exports = require('../../netlify/functions/_supabase-env.js');
