module.exports = require('../../netlify/functions/admin-settings-get.js');
