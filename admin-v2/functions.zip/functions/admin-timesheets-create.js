module.exports = require('../../netlify/functions/admin-timesheets-create.js');
