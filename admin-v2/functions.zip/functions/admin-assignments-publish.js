module.exports = require('../../netlify/functions/admin-assignments-publish.js');
