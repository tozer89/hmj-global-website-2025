module.exports = require('../../netlify/functions/_jobs-helpers.js');
