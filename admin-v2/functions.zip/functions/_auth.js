module.exports = require('../../netlify/functions/_auth.js');
