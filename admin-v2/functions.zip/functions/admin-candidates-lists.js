module.exports = require('../../netlify/functions/admin-candidates-lists.js');
