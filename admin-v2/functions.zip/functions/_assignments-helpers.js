module.exports = require('../../netlify/functions/_assignments-helpers.js');
