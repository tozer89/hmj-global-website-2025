module.exports = require('../../netlify/functions/identity-proxy.js');
