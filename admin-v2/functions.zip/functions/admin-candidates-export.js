module.exports = require('../../netlify/functions/admin-candidates-export.js');
